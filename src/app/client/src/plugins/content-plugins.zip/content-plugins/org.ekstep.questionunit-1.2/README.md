# org.ekstep.plugins.test

This plugin is an example plugin

### Usage

How do people use this plugin?

### Development

Please refer to [wiki](https://github.com/ekstep/Contributed-Plugins/wiki) for plugin development guidelines